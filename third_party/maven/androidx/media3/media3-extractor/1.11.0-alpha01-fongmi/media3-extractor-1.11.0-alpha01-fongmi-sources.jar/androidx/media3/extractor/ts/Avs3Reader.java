/*
 * Copyright (C) 2016 The Android Open Source Project
 * Copyright 2026 WebHTV contributors
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy at https://www.apache.org/licenses/LICENSE-2.0
 */
package androidx.media3.extractor.ts;

import static com.google.common.base.Preconditions.checkNotNull;

import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.ParserException;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.container.NalUnitUtil;
import androidx.media3.extractor.Avs3Config;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.TrackOutput;
import java.util.Arrays;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;

/** AVS3 access-unit reader using Media3's H262Reader start-code/PES accounting. */
@UnstableApi
public final class Avs3Reader implements ElementaryStreamReader {
  private static final int SEQUENCE = 0xb0;
  private static final int I_PICTURE = 0xb3;
  private static final int PB_PICTURE = 0xb6;
  private final boolean[] prefixFlags = new boolean[4];
  private final byte[] sequence = new byte[65535];
  private @MonotonicNonNull TrackOutput output;
  private @MonotonicNonNull String formatId;
  private int sequenceLength;
  private boolean collectingSequence;
  private boolean hasFormat;
  private long frameDurationUs;
  private long totalBytesWritten;
  private long samplePosition;
  private long sampleTimeUs = C.TIME_UNSET;
  private long pesTimeUs = C.TIME_UNSET;
  private boolean startedSample;
  private boolean sampleHasPicture;
  private boolean sampleIsKeyframe;

  @Override
  public void seek() {
    NalUnitUtil.clearPrefixFlags(prefixFlags);
    collectingSequence = false;
    sequenceLength = 0;
    totalBytesWritten = 0;
    startedSample = false;
    sampleHasPicture = false;
    sampleIsKeyframe = false;
    sampleTimeUs = C.TIME_UNSET;
    pesTimeUs = C.TIME_UNSET;
  }

  @Override
  public void createTracks(ExtractorOutput extractorOutput, TsPayloadReader.TrackIdGenerator ids) {
    ids.generateNewId();
    formatId = ids.getFormatId();
    output = extractorOutput.track(ids.getTrackId(), C.TRACK_TYPE_VIDEO);
  }

  @Override
  public void packetStarted(long timeUs, @TsPayloadReader.Flags int flags) {
    pesTimeUs = timeUs;
  }

  @Override
  public void consume(ParsableByteArray data) throws ParserException {
    checkNotNull(output);
    int offset = data.getPosition();
    int limit = data.limit();
    byte[] bytes = data.getData();
    totalBytesWritten += data.bytesLeft();
    output.sampleData(data, data.bytesLeft());
    while (true) {
      int start = NalUnitUtil.findNalUnit(bytes, offset, limit, prefixFlags);
      if (start == limit) {
        appendSequence(bytes, offset, limit);
        return;
      }
      int code = bytes[start + 3] & 0xff;
      int length = start - offset;
      if (!hasFormat) {
        if (length > 0) appendSequence(bytes, offset, start);
        if (collectingSequence) {
          sequenceLength -= Math.max(0, -length);
          if (code == I_PICTURE || code == PB_PICTURE || code == SEQUENCE || code == 0xb1) {
            Avs3Config config = Avs3Config.parse(Arrays.copyOf(sequence, sequenceLength));
            output.format(new Format.Builder().setId(formatId)
                .setContainerMimeType(MimeTypes.VIDEO_MP2T)
                .setSampleMimeType(MimeTypes.VIDEO_AVS3).setCodecs(config.codecs)
                .setWidth(config.width).setHeight(config.height).setFrameRate(config.frameRate)
                .setPixelWidthHeightRatio(config.pixelWidthHeightRatio)
                .setInitializationData(config.initializationData)
                .setColorInfo(new ColorInfo.Builder().setLumaBitdepth(config.bitdepth)
                    .setChromaBitdepth(config.bitdepth).build()).build());
            frameDurationUs = config.frameRate > 0 ? (long) (1_000_000d / config.frameRate) : 0;
            hasFormat = true;
            collectingSequence = false;
          }
        }
        if (!hasFormat) {
          if (code == SEQUENCE) {
            collectingSequence = true;
            sequenceLength = 0;
          }
          appendSequence(new byte[] {0, 0, 1}, 0, 3);
        }
      }
      if (code == SEQUENCE || code == I_PICTURE || code == PB_PICTURE) {
        int bytesPastStart = limit - start;
        if (sampleHasPicture && hasFormat && sampleTimeUs != C.TIME_UNSET) {
          output.sampleMetadata(sampleTimeUs, sampleIsKeyframe ? C.BUFFER_FLAG_KEY_FRAME : 0,
              (int) (totalBytesWritten - samplePosition) - bytesPastStart, bytesPastStart, null);
        }
        if (!startedSample || sampleHasPicture) {
          samplePosition = totalBytesWritten - bytesPastStart;
          sampleTimeUs = pesTimeUs != C.TIME_UNSET ? pesTimeUs
              : sampleTimeUs != C.TIME_UNSET ? sampleTimeUs + frameDurationUs : C.TIME_UNSET;
          pesTimeUs = C.TIME_UNSET;
          sampleIsKeyframe = false;
          startedSample = true;
        }
        sampleHasPicture = code == I_PICTURE || code == PB_PICTURE;
        sampleIsKeyframe |= code == I_PICTURE;
      }
      offset = start + 3;
    }
  }

  @Override
  public void endOfInputReached() {
    if (output != null && hasFormat && sampleHasPicture && sampleTimeUs != C.TIME_UNSET) {
      output.sampleMetadata(sampleTimeUs, sampleIsKeyframe ? C.BUFFER_FLAG_KEY_FRAME : 0,
          (int) (totalBytesWritten - samplePosition), 0, null);
      sampleHasPicture = false;
    }
  }

  private void appendSequence(byte[] bytes, int offset, int limit) throws ParserException {
    if (!collectingSequence) return;
    int length = limit - offset;
    if (length > sequence.length - sequenceLength) {
      throw ParserException.createForMalformedContainer("AVS3 sequence header exceeds 65535 bytes", null);
    }
    System.arraycopy(bytes, offset, sequence, sequenceLength, length);
    sequenceLength += length;
  }
}
