/*
 * Copyright 2026 WebHTV contributors
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy at https://www.apache.org/licenses/LICENSE-2.0
 */
package androidx.media3.extractor;

import androidx.media3.common.ParserException;
import androidx.media3.common.util.ParsableBitArray;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** AVS3 sequence properties, from T/AI 109.2-2021 table 14 and the av3c record. */
@UnstableApi
public final class Avs3Config {
  private static final double[] FRAME_RATES = {
    0, 24000d / 1001, 24, 25, 30000d / 1001, 30, 50, 60000d / 1001,
    60, 100, 120, 200, 240, 300, 0, 0
  };

  public final List<byte[]> initializationData;
  public final String codecs;
  public final int profile;
  public final int width;
  public final int height;
  public final int bitdepth;
  public final float frameRate;
  public final float pixelWidthHeightRatio;

  /** Accepts an av3c payload or a start-code-prefixed sequence header. */
  public static Avs3Config parse(byte[] data) throws ParserException {
    try {
      byte[] sequence = data;
      if (data.length > 0 && data[0] == 1) {
        check(data.length >= 4, "Truncated av3c record");
        int size = ((data[1] & 0xff) << 8) | (data[2] & 0xff);
        check(size >= 13 && size <= data.length - 4, "Invalid av3c sequence length");
        sequence = Arrays.copyOfRange(data, 3, 3 + size);
      }
      check(sequence.length >= 13 && sequence.length <= 65535, "Invalid AVS3 sequence size");
      check(sequence[0] == 0 && sequence[1] == 0 && sequence[2] == 1
          && (sequence[3] & 0xff) == 0xb0, "Missing AVS3 sequence header");
      ParsableBitArray bits = new ParsableBitArray(sequence);
      bits.skipBits(32);
      int profile = bits.readBits(8);
      int level = bits.readBits(8);
      bits.skipBits(2); // progressive_sequence, field_coded_sequence
      boolean libraryStream = bits.readBit();
      if (!libraryStream && bits.readBit()) {
        bits.skipBit(); // duplicate_sequence_header_flag
      }
      check(bits.readBit(), "Invalid AVS3 width marker");
      int width = bits.readBits(14);
      check(bits.readBit(), "Invalid AVS3 height marker");
      int height = bits.readBits(14);
      bits.skipBits(2); // chroma_format
      int samplePrecision = bits.readBits(3);
      int encodingPrecision = (profile == 0x22 || profile == 0x32) ? bits.readBits(3) : 1;
      check(width > 0 && height > 0, "Invalid AVS3 dimensions");
      check(samplePrecision >= 1 && samplePrecision <= 2
          && encodingPrecision >= 1 && encodingPrecision <= 2, "Invalid AVS3 bit depth");
      check(bits.readBit(), "Invalid AVS3 aspect marker");
      int aspectRatio = bits.readBits(4);
      int rateCode = bits.readBits(4);
      float pixelRatio = 1;
      if (aspectRatio == 2) pixelRatio = 4f * height / (3f * width);
      else if (aspectRatio == 3) pixelRatio = 16f * height / (9f * width);
      else if (aspectRatio == 4) pixelRatio = 221f * height / (100f * width);
      return new Avs3Config(sequence.clone(), profile, level, width, height,
          encodingPrecision == 2 ? 10 : 8, (float) FRAME_RATES[rateCode], pixelRatio);
    } catch (IllegalArgumentException | IndexOutOfBoundsException e) {
      throw ParserException.createForMalformedContainer("Truncated AVS3 configuration", e);
    }
  }

  private Avs3Config(byte[] data, int profile, int level, int width, int height,
      int bitdepth, float frameRate, float pixelRatio) {
    this.initializationData = Collections.singletonList(data);
    this.codecs = Util.formatInvariant("avs3.%02X.%02X", profile, level);
    this.profile = profile;
    this.width = width;
    this.height = height;
    this.bitdepth = bitdepth;
    this.frameRate = frameRate;
    this.pixelWidthHeightRatio = pixelRatio;
  }

  private static void check(boolean valid, String message) throws ParserException {
    if (!valid) throw ParserException.createForMalformedContainer(message, null);
  }
}
